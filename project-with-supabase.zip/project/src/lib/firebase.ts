// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyArhpFfH3Tbq5YnsxTzyStoZ7bqLEdMIe4",
  authDomain: "code-4b5fc.firebaseapp.com",
  projectId: "code-4b5fc",
  storageBucket: "code-4b5fc.firebasestorage.app",
  messagingSenderId: "688379247125",
  appId: "1:688379247125:web:0fe2ec2599fb865349ac1c",
  measurementId: "G-L2Q12XW2RG"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const auth = getAuth(app);