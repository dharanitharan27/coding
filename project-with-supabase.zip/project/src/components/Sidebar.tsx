import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { ChevronRight, ChevronDown, Code2, Brain, Boxes, GitFork, Network, Workflow } from 'lucide-react';

interface Topic {
  id: string;
  title: string;
  icon: React.ReactNode;
  subtopics: string[];
}

const topics: Topic[] = [
  {
    id: 'basics',
    title: 'Basics',
    icon: <Code2 className="w-5 h-5" />,
    subtopics: ['Variables', 'Data Types', 'Control Flow']
  },
  {
    id: 'algorithms',
    title: 'Algorithms',
    icon: <Brain className="w-5 h-5" />,
    subtopics: ['Arrays', 'Sorting', 'Searching']
  },
  {
    id: 'data-structures',
    title: 'Data Structures',
    icon: <Boxes className="w-5 h-5" />,
    subtopics: ['Lists', 'Trees', 'Graphs']
  },
  {
    id: 'recursion',
    title: 'Recursion',
    icon: <GitFork className="w-5 h-5" />,
    subtopics: ['Basic Recursion', 'Backtracking', 'Dynamic Programming']
  },
  {
    id: 'advanced',
    title: 'Advanced Topics',
    icon: <Network className="w-5 h-5" />,
    subtopics: ['System Design', 'Design Patterns', 'Architecture']
  }
];

export default function Sidebar() {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  const toggleTopic = (topicId: string) => {
    setExpanded(prev => ({ ...prev, [topicId]: !prev[topicId] }));
  };

  return (
    <div className="w-64 bg-white h-screen border-r border-gray-200 overflow-y-auto">
      <div className="p-4">
        <div className="flex items-center space-x-2 mb-6">
          <Workflow className="w-6 h-6 text-indigo-600" />
          <span className="text-lg font-semibold">CodeMaster</span>
        </div>
        <nav>
          {topics.map((topic) => (
            <div key={topic.id} className="mb-2">
              <button
                onClick={() => toggleTopic(topic.id)}
                className="w-full flex items-center justify-between p-2 text-gray-700 hover:bg-gray-50 rounded-md"
              >
                <div className="flex items-center space-x-2">
                  {topic.icon}
                  <span>{topic.title}</span>
                </div>
                {expanded[topic.id] ? (
                  <ChevronDown className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </button>
              {expanded[topic.id] && (
                <div className="ml-6 mt-1 space-y-1">
                  {topic.subtopics.map((subtopic) => (
                    <NavLink
                      key={subtopic}
                      to={`/learn/${topic.id}/${subtopic.toLowerCase().replace(/\s+/g, '-')}`}
                      className={({ isActive }) =>
                        `block p-2 text-sm rounded-md ${
                          isActive
                            ? 'bg-indigo-50 text-indigo-600'
                            : 'text-gray-600 hover:bg-gray-50'
                        }`
                      }
                    >
                      {subtopic}
                    </NavLink>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>
      </div>
    </div>
  );
}