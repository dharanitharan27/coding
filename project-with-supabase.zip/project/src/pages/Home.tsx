import React from 'react';
import { Link } from 'react-router-dom';
import { Code2, Brain, BookOpen } from 'lucide-react';

export default function Home() {
  return (
    <div className="max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Master Coding with Structured Learning
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Your journey to becoming a proficient programmer starts here. Learn from structured content, practice with real problems, and track your progress.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 mb-16">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <Code2 className="w-12 h-12 text-indigo-600 mb-4" />
          <h3 className="text-xl font-semibold mb-2">Learn Step by Step</h3>
          <p className="text-gray-600">
            Start with the basics and progress through advanced topics at your own pace.
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <Brain className="w-12 h-12 text-indigo-600 mb-4" />
          <h3 className="text-xl font-semibold mb-2">Practice Problems</h3>
          <p className="text-gray-600">
            Reinforce your learning with carefully curated practice problems.
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <BookOpen className="w-12 h-12 text-indigo-600 mb-4" />
          <h3 className="text-xl font-semibold mb-2">Track Progress</h3>
          <p className="text-gray-600">
            Monitor your learning journey and see your improvement over time.
          </p>
        </div>
      </div>

      <div className="text-center">
        <Link
          to="/register"
          className="inline-block bg-indigo-600 text-white px-8 py-3 rounded-md font-semibold hover:bg-indigo-700 transition-colors"
        >
          Start Learning Now
        </Link>
      </div>
    </div>
  );
}